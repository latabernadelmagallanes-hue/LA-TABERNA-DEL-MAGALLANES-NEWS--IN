# LA TABERNA DEL MAGALLANES NEWS
## Guía de Despliegue Inmediato

Estructura de archivos oficial lista para publicar en GitHub Pages, Vercel o Netlify.

### Estructura:
- `index.html`: Portada Editorial Principal
- `redaccion-cms.html`: Sala de Redacción & Panel CMS
- `buscador.html`: Buscador Sabermétrico & Hemeroteca
- `roster.html`: Roster Activo & Depth Chart
- `cronica.html`: Crónica Longform & Métricas
- `vip.html`: Cabina VIP Statcast
- `404.html`: Pantalla Error 404 Offline
- `data.json`: Base de datos ligera editable
